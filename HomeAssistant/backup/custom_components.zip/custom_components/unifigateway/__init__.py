"""
Support for Unifi Security Gateway Units.

For more details about this platform, please refer to the documentation at
https://github.com/custom-components/sensor.unifigateway

"""
